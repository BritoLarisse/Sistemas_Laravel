@extends('layouts.site')

@section('titulo', 'Cursos')

@extends('main')


@section('conteudo')
<h3>Buscar Curso</h3>

<div class="row">
    <?php foreach ($curso as $key => $value): ?>
      <div class="col-md-4">
        <div class="card">
          <div class="card-image">
            <img src="{{asset($curso->imagem)}}">
          </div>
          <div class="card-content">
            <h4>{{$curso->titulo}}</h4>
            <p>{{$curso->descricao}}</p>
          </div>
          <div class="card-action">
            <a href="#">Ver mais...</a>
          </div>
        </div>
      </div>






    <?php endforeach; ?>

</div>




@endsection
