<?php $__env->startSection('title'); ?>
Minhas Anotações

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1>Anotações</h1>

   <ul>

        <?php $__currentLoopData = $notas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($nota); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

   </ul>

   <?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>