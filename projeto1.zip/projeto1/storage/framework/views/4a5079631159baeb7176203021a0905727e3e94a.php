<div class="form-group">
        <label for="title">Título:</label>
        <input type="" id="" name="title" class="form-control" value="<?php echo e($post->title); ?>">

       <br>
    </div>
    <div class="form-group">
        <label for="content">Content:</label>
        <textarea type="" name="content" class="form-control" id="content" rows="3"><?php echo e($post->title); ?></textarea>

    </div>
