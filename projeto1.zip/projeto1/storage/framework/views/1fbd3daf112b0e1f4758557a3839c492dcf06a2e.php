<?php $__env->startSection('content'); ?>

    <h1>Blog</h1>

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <h2><?php echo e($post->title); ?></h2>
        <p><?php echo e($post->content); ?></p>

      <b>Tags:</b><br>
        <ul>
            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($tag->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>

        <h3>Comments</h3>
        <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

            <b>Name: </b> <?php echo e($comment->name); ?><br>
            <b>Comment: </b> <?php echo e($comment->comment); ?>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

        <hr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>