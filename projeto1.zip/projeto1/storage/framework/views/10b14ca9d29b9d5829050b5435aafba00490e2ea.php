<?php $__env->startSection('content'); ?>

    <h1>Sistema de Cadastro</h1>

    <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-success">Cadastrar Novo Cliente</a>
<br><br>
    <table class="table">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Action</th>
        </tr>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

        <tr>
            <td><?php echo e($post->id); ?></td>
            <td><?php echo e($post->title); ?></td>
            <td>
                 <a href="<?php echo e(route('admin.posts.edit', ['id'=> $post->id])); ?>" class="btn btn-default">Editar</a>
                 <a href="<?php echo e(route('admin.posts.destroy', ['id'=> $post->id])); ?>" class="btn btn-danger">Excluir</a>
            </td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    </table>

    <?php echo $posts->render(); ?>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>