<?php $__env->startSection('titulo','Cursos'); ?>

<?php $__env->startSection('conteudo'); ?>


  <div class="container">
    <h3 class="center">Entrar</h3>
    <div class="row">

    
      <form class="" action="<?php echo e(route('site.login.entrar')); ?>" method="post">
        <?php echo e(csrf_field()); ?>


        <div class="input-field">
            <label>E-mail</label>
          <input type="text" name="email">
        </div>
        <div class="input-field">
            <label>Senha</label>
          <input type="password" name="senha">        
        </div>

        <button class="btn deep-orange">Entrar</button>
      </form>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>