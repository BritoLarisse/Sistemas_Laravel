<?php $__env->startSection('content'); ?>
   
<h1>Editar Cadastro  <?php echo e($post->title); ?></h1>


<form method="post"  action="<?php echo e(route('admin.posts.update', ['id'=> $post->id])); ?>">
    <?php echo e(csrf_field()); ?>


  <?php echo $__env->make('admin.posts._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <div class="form-group">
        <label for="tags">Tags:</label>

        <textarea type="" name="tags" class="form-control" id="tags" rows="3"><?php echo e($post->title); ?></textarea>  
             
    </div>
    
    <div class="form-group">
         <button type="submit" value="" class="btn btn-primary">Salvar</button>
    </div>  
    
</form>



    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>