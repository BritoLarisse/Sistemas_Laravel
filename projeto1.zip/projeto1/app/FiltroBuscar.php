<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

protected static function buscar()
  {
      parent::buscar();

      //filtra apenas por clientes ativos
      static::addGlobalScope('active', function (Builder $builder) {
          $builder->where('active', true);
      });

      //ordena pela data de cadastro
      static::addGlobalScope('created', function (Builder $builder) {
          $builder->orderBy('created_at');
      });
}
