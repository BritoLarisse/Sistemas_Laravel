<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Contato;

class ContatoController extends Controller
{
   public function index()
   {
      /* return view('contato.index'); */
      $contatos = [
         ( object) ["nome"=>"Maria", "tel"=>"11979659969"],
         ( object) ["nome"=>"Pedro", "tel"=>"11979659977"]
        
        ];

        $contato = new Contato();
        $con = $contato->lista();
        dd($con->nome);

        return view('contato.index', compact('contatos'));
        
   } 
   public function criar(Request $req)
   {
       dd($req->all());
       return "Esse é o criar do ContatoController";
   } 
   public function editar()
   {
       return "Esse é o editar do ContatoController";
   } 
}
